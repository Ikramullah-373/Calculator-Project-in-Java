/**
 *
 * @author Ikram Ullah Farazi
 */
package calculator;

// import java file
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;


public class Calculator implements ActionListener {     // Calculator class implements all function of ActionListener
    //define variable
    
    JFrame f;           //Jframe
    JTextField t;       //Textfield
    JButton b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,bA,bS,bSu,bD,bE,bCl,bp,bDl;
    static double a=0,b=0,result=0;     
    static int operator = 0;
    //end of define variable
    
    Calculator(){           //start Calculator method
        
        f=new JFrame("Calculator"); // implements JFrame
        
        //create textfield for disple the result
        t=new JTextField();
        t.setBounds(20,20,215,40);
        f.add(t);       //end
        
        //create button 1
        b1=new JButton("1");
        b1.setBounds(75,65,50,40);
        f.add(b1);
        b1.addActionListener(this);       //end
        
        //create button 2
        b2=new JButton("2");
        b2.setBounds(130,65,50,40);
        f.add(b2);
        b2.addActionListener(this);       //end
        
        //create button 3
        b3=new JButton("3");
        b3.setBounds(20,110,50,40);
        f.add(b3);
        b3.addActionListener(this);       //end
        
        //create button 4
        b4=new JButton("4");
        b4.setBounds(75,110,50,40);
        f.add(b4);
        b4.addActionListener(this);       //end
         
        //create button 5
        b5=new JButton("5");
        b5.setBounds(130,110,50,40);
        f.add(b5);
        b5.addActionListener(this);       //end
        
        //create button 6
        b6=new JButton("6");
        b6.setBounds(20,155,50,40);
        f.add(b6);
        b6.addActionListener(this);       //end
        
        //create button 7
        b7=new JButton("7");
        b7.setBounds(75,155,50,40);
        f.add(b7);
        b7.addActionListener(this);       //end
        
        //create button 8
        b8=new JButton("8");
        b8.setBounds(130,155,50,40);
        f.add(b8);
        b8.addActionListener(this);       //end
        
        
        //create button 9
        b9=new JButton("9");
        b9.setBounds(130,200,50,40);
        f.add(b9);
        b9.addActionListener(this);       //end
        
        //create button 0
        b0=new JButton("0");
        b0.setBounds(75,200,50,40);
        f.add(b0);
        b0.addActionListener(this);       //end
        
        //create button point or decimal
        bp=new JButton(".");
        bp.setBounds(20,200,50,40);
        f.add(bp);
        bp.addActionListener(this);       //end
        
        //create button "delete" for some numbers delete
        bDl=new JButton("<=");
        bDl.setBounds(20,245,50,40);
        f.add(bDl);
        bDl.addActionListener(this);       //end
        
        //create button divide for doing divide operation
        bA=new JButton("/");
        bA.setBounds(185,65,50,40);
        f.add(bA);
        bA.addActionListener(this);       //end
        
        //create button subtraction for subtract operation
        bS=new JButton("-");
        bS.setBounds(185,110,50,40);
        f.add(bS);
        bS.addActionListener(this);       //end
        
        //create button summation for sum operation
        bSu=new JButton("*");
        bSu.setBounds(185,155,50,40);
        f.add(bSu);
        bSu.addActionListener(this);       //end
        
        //create button Addition for add operation
        bD=new JButton("+");
        bD.setBounds(185,200,50,85);
        f.add(bD);
        bD.addActionListener(this);       //end
        
        //create button equal
        bE=new JButton("=");
        bE.setBounds(75,245,106,40);
        f.add(bE);
        bE.addActionListener(this);       //end
        
        //create button clear for all clear
        bCl=new JButton("C");
        bCl.setBounds(20,65,50,40);
        f.add(bCl);
        bCl.addActionListener(this);       //end
        
        
        
        
        f.setLayout(null);
        f.setVisible(true);
        f.setSize(275,350);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);
        
        
       
        
    }        //end of Calculator method
    
    // Main Method
    public static void main(String[] args) {
        new Calculator(); 
    }//end of main method
    

    //Main action and operation method 
    @Override
    public void actionPerformed(ActionEvent e) {    //start Action Event
        if(e.getSource()==b1)
            t.setText(t.getText().concat("1"));
        if(e.getSource()==b2)
            t.setText(t.getText().concat("2"));
        if(e.getSource()==b3)
            t.setText(t.getText().concat("3"));
        if(e.getSource()==b4)
            t.setText(t.getText().concat("4"));
        if(e.getSource()==b5)
            t.setText(t.getText().concat("5"));
        if(e.getSource()==b6)
            t.setText(t.getText().concat("6"));
        if(e.getSource()==b7)
            t.setText(t.getText().concat("7"));
        if(e.getSource()==b8)
            t.setText(t.getText().concat("8"));
        if(e.getSource()==b9)
            t.setText(t.getText().concat("9"));
        if(e.getSource()==b0)
            t.setText(t.getText().concat("0"));
      
        if(e.getSource()==bp)
            t.setText(t.getText().concat("."));
        
       //Add operation action
        if(e.getSource()==bD){
            a=Double.parseDouble(t.getText());
            operator=1;
            t.setText("");      //end
        }
        //Subtraction operation action
        if(e.getSource()==bS){
            a=Double.parseDouble(t.getText());
            operator=2;
            t.setText("");      //end
        }
        //Sum operation action
        if(e.getSource()==bSu){
            a=Double.parseDouble(t.getText());
            operator=3;
            t.setText("");      //end
        }
        //Divide operation action
         if(e.getSource()==bA){
            a=Double.parseDouble(t.getText());
            operator=4;
            t.setText("");      //end
        }
        
        if(e.getSource()==bE){
            b=Double.parseDouble(t.getText());
            switch(operator){
                case 1: result=a+b;  // if case 1 is equal operator 1 then it performs add operation
                break;
                case 2: result=a-b;  // if case 2 is equal operator 2 then it performs Subtraction operation
                break;
                case 3: result=a*b;  // if case 3 is equal operator 3 then it performs Sum operation
                break;
                case 4: result=a/b;  // if case 1 is equal operator 1 then it performs Divide operation
                break;
            }
            t.setText(""+result); //show result
        }
        // Clear operation action
        if(e.getSource()==bCl)
            t.setText("");      //end
        //Delete operation action
        if(e.getSource()==bDl){
            String s=t.getText();
            t.setText("");
            for(int i=0;i<s.length()-1;i++){ //start loop 
                t.setText(t.getText()+s.charAt(i));   // in this for loop value of i is lessthan s.length then setTex character is remove one by one
            } //end loop
        }
        
    }   //End Action Event
    
}   //End Calculator Class
